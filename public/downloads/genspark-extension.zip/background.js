var A='https://arkxmotion-studio.vercel.app';
chrome.runtime.onMessage.addListener(function(m,s,r){
  if(m.type==='TOKEN_GRABBED'&&m.provider==='genspark'){
    chrome.storage.local.set({arkx_genspark:{token:m.token,timestamp:Date.now(),url:s.tab?s.tab.url:''}});
    sync('genspark',m.token);chrome.action.setBadgeText({text:'\u2713'});chrome.action.setBadgeBackgroundColor({color:'#10b981'});
  }
  if(m.type==='GET_TOKEN'){chrome.storage.local.get('arkx_genspark',function(d){r(d.arkx_genspark||null);});return true;}
  if(m.type==='OPEN_ARKXMOTION'){chrome.tabs.create({url:A});}
  if(m.type==='MANUAL_KEY'){
    chrome.storage.local.set({arkx_genspark:{token:m.token,timestamp:Date.now(),url:'manual'}});
    sync('genspark',m.token);chrome.action.setBadgeText({text:'\u2713'});chrome.action.setBadgeBackgroundColor({color:'#10b981'});
    r({ok:true});return true;
  }
});
function sync(p,t){fetch(A+'/api/sync-tokens',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({provider:p,token:t,source:'extension'})}).catch(function(){});}
chrome.tabs.onUpdated.addListener(function(id,i,t){if(i.status==='complete'&&t.url&&t.url.indexOf('genspark.ai')>=0){chrome.scripting.executeScript({target:{tabId:id},files:['content.js']}).catch(function(){});}});
