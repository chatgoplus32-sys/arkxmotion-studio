(function(){
  'use strict';
  var K=/gsk[-_][a-zA-Z0-9_-]{16,}/,done=false;
  function emit(k){if(done||!k)return;done=true;window.postMessage({type:'ARKX_TOKEN',provider:'genspark',token:k},'*');}
  function t(x){if(!x)return false;var m=x.match(K);if(m){emit(m[0]);return true;}return false;}
  function sR(r){
    var w=document.createTreeWalker(r,NodeFilter.SHOW_TEXT);while(w.nextNode()){if(t(w.nodeValue))return;}
    var els=r.querySelectorAll('*');for(var i=0;i<els.length;i++){
      var e=els[i];if(t(e.value)||t(e.getAttribute('value'))||t(e.getAttribute('placeholder'))||t(e.getAttribute('data-value')))return;
      for(var j=0;j<e.attributes.length;j++){if(t(e.attributes[j].value))return;}
      if(e.shadowRoot)sR(e.shadowRoot);
    }
  }
  function sS(){try{[localStorage,sessionStorage].forEach(function(s){for(var i=0;i<s.length;i++){var v=s.getItem(s.key(i));if(t(v))return;try{if(t(JSON.stringify(JSON.parse(v))))return;}catch(e){}}});}catch(e){}}
  function go(){
    if(done)return;
    document.querySelectorAll('button,[role=button],span').forEach(function(b){
      var x=(b.textContent||'').toLowerCase();
      if(x.indexOf('show')>=0||x.indexOf('reveal')>=0||x.indexOf('eye')>=0||x.indexOf('view')>=0)b.click();
    });
    sR(document.body||document.documentElement);sS();
    var m=document.documentElement.outerHTML.match(K);if(m)emit(m[0]);
  }
  go();var c=0;var iv=setInterval(function(){if(done||c++>40){clearInterval(iv);return;}go();},1500);
  var obs=new MutationObserver(function(){if(!done)go();});
  obs.observe(document.documentElement,{childList:true,subtree:true,attributes:true});
  window.addEventListener('message',function(e){if(e.source!==window)return;if(e.data&&e.data.type==='ARKX_TOKEN'&&e.data.provider==='genspark'){chrome.runtime.sendMessage({type:'TOKEN_GRABBED',provider:'genspark',token:e.data.token});}});
})();
