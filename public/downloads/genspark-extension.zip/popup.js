document.addEventListener('DOMContentLoaded',function(){
  var st=document.getElementById('st'),tp=document.getElementById('tp'),sy=document.getElementById('sync'),
      gb=document.getElementById('gb'),ab=document.getElementById('ab'),mk=document.getElementById('mk'),mb=document.getElementById('mb');
  function SS(t,x){st.className='st '+t;st.innerHTML='<span class="dot '+t+'"></span><span>'+x+'</span>';}
  function M(t){return t&&t.length>20?t.slice(0,15)+'...'+t.slice(-8):t;}
  chrome.storage.local.get('arkx_genspark',function(d){
    var s=d.arkx_genspark;if(s&&s.token){SS('ok','Key saved');tp.style.display='block';tp.textContent=M(s.token);sy.style.display='block';mk.value=s.token;}
  });
  gb.addEventListener('click',function(){
    SS('load','Scanning... (key must be visible)');
    chrome.tabs.query({active:true,currentWindow:true},function(tabs){
      var tab=tabs[0];if(!tab){SS('err','No tab');return;}
      if(tab.url&&tab.url.indexOf('genspark.ai')<0){SS('err','Open genspark.ai first');return;}
      chrome.scripting.executeScript({target:{tabId:tab.id},files:['content.js']},function(){
        setTimeout(function(){if(st.className.indexOf('load')>=0)SS('err','Key not found - click eye icon first');},5000);
      });
    });
  });
  mb.addEventListener('click',function(){
    var k=mk.value.trim();if(!k){SS('err','Enter key');return;}
    if(k.indexOf('gsk-')!==0&&k.indexOf('gsk_')!==0){SS('err','Must start with gsk- or gsk_');return;}
    chrome.runtime.sendMessage({type:'MANUAL_KEY',token:k},function(r){
      if(r&&r.ok){SS('ok','Saved and synced');tp.style.display='block';tp.textContent=M(k);sy.style.display='block';}else SS('err','Failed');
    });
  });
  mk.addEventListener('keydown',function(e){if(e.key==='Enter')mb.click();});
  ab.addEventListener('click',function(){chrome.runtime.sendMessage({type:'OPEN_ARKXMOTION'});});
});
