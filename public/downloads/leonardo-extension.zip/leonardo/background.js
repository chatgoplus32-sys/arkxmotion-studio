// ARKXMotion Extension — Leonardo AI
// Background service worker with auto-sync

const API_URL = 'https://arkxmotion-studio.win';

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'TOKEN_GRABBED' && msg.provider === 'leonardo') {
    chrome.storage.local.set({
      arkx_leonardo: { token: msg.token, timestamp: Date.now(), url: sender.tab?.url || '' }
    });
    syncToken('leonardo', msg.token);
    chrome.action.setBadgeText({ text: '✓' });
    chrome.action.setBadgeBackgroundColor({ color: '#10b981' });
    chrome.notifications?.create({
      type: 'basic',
      iconUrl: 'icon.png',
      title: 'ARKXMotion — Leonardo AI',
      message: 'Token berhasil di-grab & sync ke Token Manager!',
    });
  }

  if (msg.type === 'TOKEN_ERROR' && msg.provider === 'leonardo') {
    chrome.action.setBadgeText({ text: '!' });
    chrome.action.setBadgeBackgroundColor({ color: '#ef4444' });
  }

  if (msg.type === 'GET_TOKEN') {
    chrome.storage.local.get('arkx_leonardo', (data) => {
      sendResponse(data.arkx_leonardo || null);
    });
    return true;
  }

  if (msg.type === 'OPEN_ARKXMOTION') {
    chrome.tabs.create({ url: API_URL });
  }
});

async function syncToken(provider, token) {
  try {
    await fetch(API_URL + '/api/sync-tokens', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ provider, token, source: 'extension' }),
    });
    console.log('[ARKX] Token synced for', provider);
  } catch (e) {
    console.error('[ARKX] Sync failed:', e);
  }
}

chrome.tabs.onUpdated.addListener((tabId, info, tab) => {
  if (info.status === 'complete' && tab.url) {
    const matches = ["app.leonardo.ai","cloud.leonardo.ai"];
    if (matches.some(d => tab.url.includes(d))) {
      chrome.scripting.executeScript({ target: { tabId }, files: ['content.js'] });
    }
  }
});
