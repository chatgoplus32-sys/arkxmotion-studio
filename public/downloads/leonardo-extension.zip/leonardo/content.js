(function() {
  'use strict';
  function checkStorage(storage) {
    for (const key of Object.keys(storage)) {
      const val = storage.getItem(key);
      if (val && val.includes('eyJ')) return val;
    }
    return null;
  }
  let token = checkStorage(localStorage) || checkStorage(sessionStorage);
  if (token) window.postMessage({ type: 'ARKX_TOKEN', provider: 'leonardo', token: token }, '*');

  fetch('/api/auth/session').then(r => r.json()).then(data => {
    const t = data?.accessToken || data?.access_token;
    if (t) window.postMessage({ type: 'ARKX_TOKEN', provider: 'leonardo', token: t }, '*');
  }).catch(() => {});

  window.addEventListener('message', (event) => {
    if (event.source !== window) return;
    if (event.data?.type === 'ARKX_TOKEN' && event.data.provider === 'leonardo') {
      chrome.runtime.sendMessage({ type: 'TOKEN_GRABBED', provider: 'leonardo', token: event.data.token });
    }
  });
})();