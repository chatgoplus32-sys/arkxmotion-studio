document.addEventListener('DOMContentLoaded', () => {
  const st = document.getElementById('st');
  const tp = document.getElementById('tp');
  const sync = document.getElementById('sync');
  const gb = document.getElementById('gb');
  const ab = document.getElementById('ab');

  function setStatus(type, text) {
    st.className = 'st ' + type;
    st.innerHTML = '<span class="dot ' + type + '"></span><span>' + text + '</span>';
  }
  function mask(t) { return t && t.length > 20 ? t.slice(0,15) + '...' + t.slice(-8) : t; }

  chrome.storage.local.get('arkx_leonardo', (data) => {
    const s = data.arkx_leonardo;
    if (s?.token) {
      setStatus('ok', 'Token tersimpan ✓');
      tp.style.display = 'block';
      tp.textContent = mask(s.token);
      sync.style.display = 'block';
    }
  });

  gb.addEventListener('click', async () => {
    setStatus('load', 'Grabbing token...');
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    try {
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['content.js'] });
      setTimeout(() => { if (st.classList.contains('load')) setStatus('err', 'Timeout — pastikan sudah login'); }, 10000);
    } catch(e) { setStatus('err', 'Error: ' + e.message); }
  });

  ab.addEventListener('click', () => { chrome.runtime.sendMessage({ type: 'OPEN_ARKXMOTION' }); });
});