// MarkasTools Cookie Manager — background service worker.
//
// Auto-sync: tiap 5 menit (chrome.alarms) cookie sesi ai.markastools.id
// dikirim ke antrean /api/sync-tokens ArkxMotion sebagai provider
// 'markastools' kind 'cookie'. App-side (tokenAutoSync) mengambilnya ≤30
// detik lalu menaruhnya di field `cookies` key session — jadi cookie yang
// expire tidak perlu di-paste ulang manual.

const MT_DOMAIN = 'ai.markastools.id'
const ALARM = 'mt-sync'

async function buildCookieHeader() {
  const all = await chrome.cookies.getAll({ domain: MT_DOMAIN })
  const usable = all.filter((c) => c && c.value)
  if (!usable.length) return ''
  return usable.map((c) => `${c.name}=${c.value}`).join('; ')
}

async function syncOnce() {
  const data = await chrome.storage.local.get(['mt_app_url', 'mt_app_token'])
  const base = (data.mt_app_url || 'https://arkxmotion-studio.win').replace(/\/+$/, '')
  const token = (data.mt_app_token || '').trim()
  if (!token) return { ok: false, error: 'Token app belum diisi' }

  const header = await buildCookieHeader()
  if (!header) return { ok: false, error: 'Belum ada cookie MarkasTools' }

  try {
    const res = await fetch(`${base}/api/sync-tokens`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({ provider: 'markastools', token: header, kind: 'cookie', source: 'extension:auto' }),
    })
    const text = await res.text()
    let json = null
    try { json = JSON.parse(text) } catch { /* bukan JSON */ }
    if (!res.ok) return { ok: false, error: json?.error || `HTTP ${res.status}` }
    return { ok: true, message: json?.message || 'synced' }
  } catch (e) {
    return { ok: false, error: e?.message || 'network error' }
  }
}

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name !== ALARM) return
  const res = await syncOnce()
  await chrome.storage.local.set({
    mt_last_sync: Date.now(),
    mt_last_sync_msg: res.ok ? res.message : res.error,
  })
})

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg?.type === 'sync_now') {
    syncOnce().then((res) => sendResponse(res))
    return true
  }
  return false
})
