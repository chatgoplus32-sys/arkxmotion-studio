// MarkasTools Cookie Manager — popup
//
// Cookie session ai.markastools.id biasanya HttpOnly, jadi tidak bisa dibaca
// dari Console/bookmarklet. API chrome.cookies bisa membacanya (termasuk
// HttpOnly), lalu:
//   * "Cek Sesi"  → validasi lewat relay publik ArkxMotion
//                    (POST/GET /api/public/markastools/api/me + header Cookie)
//   * "Kirim ke App" → antrekan cookie ke ARKxMotion (provider 'markastools',
//                    kind 'cookie') supaya app memakai sesi itu otomatis.

const MT_DOMAIN = 'ai.markastools.id'
const DEFAULT_APP_URL = 'https://arkxmotion-studio.win'

const $ = (id) => document.getElementById(id)
const ui = {
  dot: $('dot'), status: $('status'), cookieList: $('cookieList'), msg: $('msg'),
  appUrl: $('appUrl'), appToken: $('appToken'), autoSync: $('autoSync'),
}

let currentHeader = ''

function setMsg(text, kind) {
  ui.msg.textContent = text || ''
  ui.msg.className = 'msg' + (kind ? ' ' + kind : '')
}

function appUrl() {
  return (ui.appUrl.value || DEFAULT_APP_URL).trim().replace(/\/+$/, '')
}

function mask(value) {
  const s = String(value || '')
  if (s.length <= 8) return s.slice(0, 2) + '…'
  return s.slice(0, 4) + '…' + s.slice(-3)
}

async function readCookies() {
  const all = await chrome.cookies.getAll({ domain: MT_DOMAIN })
  return all.filter((c) => c && c.value)
}

function buildHeader(cookies) {
  return cookies.map((c) => `${c.name}=${c.value}`).join('; ')
}

function renderCookies(cookies) {
  if (!cookies.length) {
    ui.cookieList.textContent = 'Tidak ada cookie untuk ai.markastools.id — login dulu di situsnya.'
    return
  }
  ui.cookieList.textContent = cookies.map((c) => `${c.name}=${mask(c.value)}`).join('\n')
}

async function doRead() {
  setMsg('Membaca cookie…')
  const cookies = await readCookies()
  renderCookies(cookies)
  if (!cookies.length) {
    currentHeader = ''
    ui.dot.className = 'dot'
    ui.status.textContent = 'Belum ada cookie'
    ui.status.className = 'bad'
    setMsg('Login di https://ai.markastools.id lalu klik lagi.', 'bad')
    return
  }
  currentHeader = buildHeader(cookies)
  ui.dot.className = 'dot ok'
  ui.status.textContent = `${cookies.length} cookie ditemukan`
  ui.status.className = 'ok'
  setMsg(`Header Cookie siap (${currentHeader.length} karakter).`, 'ok')
}

async function doCheck() {
  if (!currentHeader) await doRead()
  if (!currentHeader) return
  setMsg('Mengecek sesi di MarkasTools…')
  try {
    const res = await fetch(`${appUrl()}/api/public/markastools/api/me`, {
      method: 'GET',
      headers: { 'X-Markastools-Cookie': currentHeader },
    })
    const text = await res.text()
    let data = null
    try { data = JSON.parse(text) } catch { /* bukan JSON */ }
    if (res.ok && data && data.ok) {
      ui.dot.className = 'dot ok'
      ui.status.textContent = 'Sesi valid'
      ui.status.className = 'ok'
      const name = data.user?.name || data.user?.email || ''
      setMsg(`✓ Sesi aktif${name ? ' — ' + name : ''}${data.user?.plan ? ' · paket ' + data.user.plan : ''}`, 'ok')
    } else {
      ui.dot.className = 'dot bad'
      ui.status.textContent = 'Sesi ditolak'
      ui.status.className = 'bad'
      const code = data?.code ? ` (${data.code})` : ''
      setMsg(`✗ Ditolak${code}. ${data?.error || 'Cookie mungkin belum lengkap / sesi logout.'}`, 'bad')
    }
  } catch (e) {
    setMsg('✗ Gagal menghubungi relay app: ' + (e?.message || e), 'bad')
  }
}

async function doCopy() {
  if (!currentHeader) await doRead()
  if (!currentHeader) return
  try {
    await navigator.clipboard.writeText(currentHeader)
    setMsg('✓ Cookie disalin ke clipboard. Tempel di ArkxMotion → Providers → MarkasTools → kolom cookie → Simpan Sesi.', 'ok')
  } catch (e) {
    setMsg('✗ Gagal copy: ' + (e?.message || e), 'bad')
  }
}

async function doSend() {
  if (!currentHeader) await doRead()
  if (!currentHeader) return
  const token = (ui.appToken.value || '').trim()
  if (!token) {
    setMsg('✗ Isi "Token App" dulu (tombol “Salin token app” di ArkxMotion → Providers → MarkasTools).', 'bad')
    return
  }
  setMsg('Mengirim ke ArkxMotion…')
  try {
    const res = await fetch(`${appUrl()}/api/sync-tokens`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({ provider: 'markastools', token: currentHeader, kind: 'cookie', source: 'extension' }),
    })
    const text = await res.text()
    let data = null
    try { data = JSON.parse(text) } catch { /* bukan JSON */ }
    if (res.ok && data && data.ok) {
      setMsg(`✓ Terkirim ke ArkxMotion (${data.tokenCount} token di antrean). App mengambilnya otomatis ≤30 detik.`, 'ok')
    } else {
      setMsg('✗ Ditolak: ' + (data?.error || 'HTTP ' + res.status), 'bad')
    }
  } catch (e) {
    setMsg('✗ Gagal mengirim: ' + (e?.message || e), 'bad')
  }
}

function saveSettings() {
  chrome.storage.local.set({
    mt_app_url: appUrl(),
    mt_app_token: (ui.appToken.value || '').trim(),
    mt_auto_sync: !!ui.autoSync.checked,
  })
  if (ui.autoSync.checked) {
    chrome.alarms.create('mt-sync', { periodInMinutes: 5 })
  } else {
    chrome.alarms.clear('mt-sync')
  }
}

document.addEventListener('DOMContentLoaded', async () => {
  chrome.storage.local.get(['mt_app_url', 'mt_app_token', 'mt_auto_sync'], (d) => {
    ui.appUrl.value = d.mt_app_url || DEFAULT_APP_URL
    ui.appToken.value = d.mt_app_token || ''
    ui.autoSync.checked = !!d.mt_auto_sync
    if (ui.autoSync.checked) chrome.alarms.create('mt-sync', { periodInMinutes: 5 })
  })

  $('btnRead').addEventListener('click', doRead)
  $('btnCheck').addEventListener('click', doCheck)
  $('btnCopy').addEventListener('click', doCopy)
  $('btnSend').addEventListener('click', async () => { await doSend(); saveSettings() })
  ui.appUrl.addEventListener('change', saveSettings)
  ui.appToken.addEventListener('change', saveSettings)
  ui.autoSync.addEventListener('change', saveSettings)

  await doRead()
})
