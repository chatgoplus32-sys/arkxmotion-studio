// ARKXMotion Extension — Roboneo
// Background service worker with auto-sync

const API_URL = 'https://arkxmotion-studio.vercel.app';

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'TOKEN_GRABBED' && msg.provider === 'roboneo') {
    chrome.storage.local.set({
      arkx_roboneo: { token: msg.token, timestamp: Date.now(), url: sender.tab?.url || '' }
    });
    syncToken('roboneo', msg.token);
    chrome.action.setBadgeText({ text: '✓' });
    chrome.action.setBadgeBackgroundColor({ color: '#10b981' });
    chrome.notifications?.create({
      type: 'basic',
      iconUrl: 'icon.png',
      title: 'ARKXMotion — Roboneo',
      message: 'Token berhasil di-grab & sync ke Token Manager!',
    });
  }

  if (msg.type === 'TOKEN_ERROR' && msg.provider === 'roboneo') {
    chrome.action.setBadgeText({ text: '!' });
    chrome.action.setBadgeBackgroundColor({ color: '#ef4444' });
  }

  if (msg.type === 'GET_TOKEN') {
    chrome.storage.local.get('arkx_roboneo', (data) => {
      sendResponse(data.arkx_roboneo || null);
    });
    return true;
  }

  if (msg.type === 'OPEN_ARKXMOTION') {
    chrome.tabs.create({ url: API_URL });
  }
});

async function syncToken(provider, token) {
  try {
    await fetch(API_URL + '/api/sync-tokens', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ provider, token, source: 'extension' }),
    });
    console.log('[ARKX] Token synced for', provider);
  } catch (e) {
    console.error('[ARKX] Sync failed:', e);
  }
}

chrome.tabs.onUpdated.addListener((tabId, info, tab) => {
  if (info.status === 'complete' && tab.url) {
    const matches = ["roboneo.com","*.roboneo.com"];
    if (matches.some(d => tab.url.includes(d))) {
      chrome.scripting.executeScript({ target: { tabId }, files: ['content.js'] });
    }
  }
});
