(function() {
  'use strict';
  function checkStorage(storage) {
    for (const key of Object.keys(storage)) {
      const val = storage.getItem(key);
      if (val && val.startsWith('eyJ')) return val;
      try {
        const parsed = JSON.parse(val);
        if (parsed?.access_token) return parsed.access_token;
      } catch(e) {}
    }
    return null;
  }
  let token = checkStorage(localStorage);
  if (token) window.postMessage({ type: 'ARKX_TOKEN', provider: 'roboneo', token: token }, '*');

  fetch('/api/auth/session').then(r => r.json()).then(data => {
    const t = data?.accessToken || data?.access_token;
    if (t) window.postMessage({ type: 'ARKX_TOKEN', provider: 'roboneo', token: t }, '*');
  }).catch(() => {});

  window.addEventListener('message', (event) => {
    if (event.source !== window) return;
    if (event.data?.type === 'ARKX_TOKEN' && event.data.provider === 'roboneo') {
      chrome.runtime.sendMessage({ type: 'TOKEN_GRABBED', provider: 'roboneo', token: event.data.token });
    }
  });
})();