// ARKXMotion Extension — Weavy
// Background service worker with auto-sync

const API_URL = 'https://arkxmotion-studio.win';

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'TOKEN_GRABBED' && msg.provider === 'weavy') {
    chrome.storage.local.set({
      arkx_weavy: { token: msg.token, timestamp: Date.now(), url: sender.tab?.url || '' }
    });
    syncToken('weavy', msg.token);
    chrome.action.setBadgeText({ text: '✓' });
    chrome.action.setBadgeBackgroundColor({ color: '#10b981' });
    chrome.notifications?.create({
      type: 'basic',
      iconUrl: 'icon.png',
      title: 'ARKXMotion — Weavy',
      message: 'Token berhasil di-grab & sync ke Token Manager!',
    });
  }

  if (msg.type === 'TOKEN_ERROR' && msg.provider === 'weavy') {
    chrome.action.setBadgeText({ text: '!' });
    chrome.action.setBadgeBackgroundColor({ color: '#ef4444' });
  }

  if (msg.type === 'GET_TOKEN') {
    chrome.storage.local.get('arkx_weavy', (data) => {
      sendResponse(data.arkx_weavy || null);
    });
    return true;
  }

  if (msg.type === 'OPEN_ARKXMOTION') {
    chrome.tabs.create({ url: API_URL });
  }
});

async function syncToken(provider, token) {
  try {
    await fetch(API_URL + '/api/sync-tokens', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ provider, token, source: 'extension' }),
    });
    console.log('[ARKX] Token synced for', provider);
  } catch (e) {
    console.error('[ARKX] Sync failed:', e);
  }
}

chrome.tabs.onUpdated.addListener((tabId, info, tab) => {
  if (info.status === 'complete' && tab.url) {
    const matches = ["app.weavy.ai"];
    if (matches.some(d => tab.url.includes(d))) {
      chrome.scripting.executeScript({ target: { tabId }, files: ['content.js'] });
    }
  }
});
