(function() {
  'use strict';
  async function grabFromIndexedDB() {
    try {
      const dbs = await indexedDB.databases();
      for (const db of dbs) {
        const idb = await new Promise((resolve) => {
          const req = indexedDB.open(db.name);
          req.onsuccess = () => resolve(req.result);
        });
        for (const name of Array.from(idb.objectStoreNames)) {
          const tx = idb.transaction(name, 'readonly');
          const store = tx.objectStore(name);
          const data = await new Promise((resolve) => {
            const req = store.getAll();
            req.onsuccess = () => resolve(req.result);
          });
          for (const item of data) {
            if (item?.access_token || item?.token) {
              const token = item.access_token || item.token;
              window.postMessage({ type: 'ARKX_TOKEN', provider: 'weavy', token: token }, '*');
              return token;
            }
          }
        }
      }
    } catch(e) {}
    return null;
  }

  // Also try localStorage
  function checkStorage() {
    for (const key of Object.keys(localStorage)) {
      const val = localStorage.getItem(key);
      if (val && val.length > 50) {
        try {
          const parsed = JSON.parse(val);
          if (parsed?.access_token) return parsed.access_token;
        } catch(e) {
          if (val.startsWith('eyJ')) return val;
        }
      }
    }
    return null;
  }

  // Try session API
  fetch('/api/auth/session').then(r => r.json()).then(data => {
    const t = data?.accessToken || data?.access_token || data?.session?.access_token;
    if (t) window.postMessage({ type: 'ARKX_TOKEN', provider: 'weavy', token: t }, '*');
  }).catch(() => {});

  checkStorage() ? window.postMessage({ type: 'ARKX_TOKEN', provider: 'weavy', token: checkStorage() }, '*') : null;
  grabFromIndexedDB();

  window.addEventListener('message', (event) => {
    if (event.source !== window) return;
    if (event.data?.type === 'ARKX_TOKEN' && event.data.provider === 'weavy') {
      chrome.runtime.sendMessage({ type: 'TOKEN_GRABBED', provider: 'weavy', token: event.data.token });
    }
  });
})();